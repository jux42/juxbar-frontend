export const environment = {
  production: false,
  apiUrl: 'localhost:8080'
};
