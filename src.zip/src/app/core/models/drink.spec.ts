import { Drink } from './drink';

describe('Drink', () => {
  it('should create an instance', () => {
    expect(new Drink()).toBeTruthy();
  });
});
