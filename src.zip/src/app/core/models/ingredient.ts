export class Ingredient {

  id!: number;

  strIngredient!: string;

  idIngredient!: string;

  strDescription!: string;
}
