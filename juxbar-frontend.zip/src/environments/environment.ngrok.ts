export const environment = {
  production: false,
  apiUrl: 'https://juxbar-backend.eu.ngrok.io'
};
