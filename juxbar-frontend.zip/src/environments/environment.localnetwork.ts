export const environment = {
  production: false,
  apiUrl: 'http://192.168.1.200:8080'
};
