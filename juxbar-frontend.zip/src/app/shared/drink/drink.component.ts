import {ChangeDetectorRef, Component, Input, OnDestroy, OnInit} from '@angular/core';
import {Cocktail} from "../../core/models/cocktail";
import {CocktailService} from "../../core/services/cocktailService";
import {Subject} from "rxjs";
import {Router, RouterLink} from "@angular/router";
import {environment} from "../../../environments/environment";
import {UserRequest} from "../../core/models/UserRequest";
import {PersonalCocktail} from "../../core/models/personal-cocktail";
import {FavouriteService} from "../../core/services/favourite.service";
import {NgClass, NgForOf, NgIf, TitleCasePipe} from "@angular/common";
import {LazyLoadImageModule} from "ng-lazyload-image";
import {DrinkService} from "../../core/services/drink.service";

@Component({
  selector: 'app-drink',
  standalone: true,
  imports: [
    NgForOf,
    NgIf,
    TitleCasePipe,
    RouterLink,
    LazyLoadImageModule,
    NgClass
  ],
  templateUrl: './drink.component.html',
  styleUrl: './drink.component.scss'
})
export class DrinkComponent implements OnInit, OnDestroy {
  @Input() drinkType!: string;

  @Input() drink !: any;
  id!: number;
  imageLoaded: { [key: string]: boolean } = {};
  isFavourite: boolean = false;
  @Input() userRequest!: UserRequest
  mouseIsOn: boolean = false;
  protected readonly environment = environment;
  protected readonly PersonalCocktail = PersonalCocktail;
  private destroy$ = new Subject<void>();

  constructor(private cdr: ChangeDetectorRef,
              private router: Router,
              private drinkService: DrinkService,
              private favouriteService: FavouriteService) {
  }

  ngOnInit() {


    if (this.drink) {

      this.checkFavourites();
      this.cdr.detectChanges();
    }
  }

  ngOnDestroy() {
    this.destroy$.next();
    this.destroy$.complete();
  }

  checkFavourites() {
    let userFav = JSON.parse(sessionStorage.getItem(`favourite${this.drinkType}s`) || '[]');
    // console.log(userFav);
    this.isFavourite = userFav.some((fav: any) => fav.id === this.drink.id);
  }

  onAddFavourite(drink: any): void {
    if (sessionStorage.getItem('username') == null) {
      this.router.navigate(['/login']);

    } else {

      if (!this.isFavourite) {
        let userFav = JSON.parse(sessionStorage.getItem(`favourite${this.drinkType}s`) || '[]');
        this.drinkService.addFavourite(drink.id, this.drinkType).subscribe(
          fav => {
            this.isFavourite = true;
          }
        );
        userFav.push(this.drink);
        sessionStorage.setItem(`favourite${this.drinkType}s`, JSON.stringify(userFav));
      } else {
        alert("This is already a fav");
      }
      this.checkFavourites();
      this.cdr.detectChanges();

    }

  }

  onMouseEnter() {
    this.mouseIsOn = true;
    console.log("mouse enter");
  }

  onMouseLeave() {
    this.mouseIsOn = false;
    console.log("mouse leave");
  }

  onRemoveFavourite(drink: any): void {
    if (this.isFavourite) {
      let userFav = JSON.parse(sessionStorage.getItem('favouritecocktails') || '[]');
      this.drinkService.removeFavourite(drink.id, this.drinkType).subscribe(
        fav => {
          this.isFavourite = false;
          this.favouriteService.announceFavouriteRemoved(drink.id, 'cocktail');
        }
      );

      const filteredFavs = userFav.filter((fav: any) => {
        fav != drink
      })
      sessionStorage.setItem('favouritecocktails', JSON.stringify(filteredFavs));
    } else {
      alert("This is NOT a fav yet");
    }
    this.checkFavourites();
    this.cdr.detectChanges();
  }

  truncateText(text: string, maxLength: number): string {
    if (text.length > maxLength) {
      return text.substring(0, maxLength) + '...';
    } else {
      return text;
    }
  }

  goTodrink() {
    window.scrollTo({
      top: 0,
      left: 0,
      behavior: 'auto'
    });
    this.router.navigateByUrl(`juxbar/one${this.drinkType}/${this.drink.id}`)
  }

  getIngredients(drink: any): string[] {
    let ingredients: string[] = [];

    for (let i = 1; i <= 6; i++) {
      const ingredient = drink[`strIngredient${i}`];
      if (ingredient) {
        ingredients.push(ingredient);
      }
    }

    return ingredients;
  }
}
