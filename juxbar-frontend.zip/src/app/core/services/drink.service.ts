import {HttpClient, HttpParams} from "@angular/common/http";
import {Injectable, Input} from "@angular/core";
import {map, Observable, of, shareReplay, switchMap, tap} from "rxjs";
import {Cocktail} from "../models/cocktail";
import {environment} from "../../../environments/environment";
import {PersonalCocktail} from "../models/personal-cocktail";
import {AuthService} from "../login/auth-service";
import {take} from "rxjs/operators";
import {State} from "../models/state";
import {Drink} from "../models/drink";

@Injectable({
  providedIn: 'root'

})


export class DrinkService {


  @Input() drink: any;
  @Input() drinkType!: string;

  private favouriteDrinks$ = this.getFavouriteDrinks(this.drinkType).pipe(
    shareReplay(1)
  );
  private allDrinks$ = this.getAllDrinks().pipe(
    shareReplay(1)
  );

  constructor(private http: HttpClient, private authService: AuthService) {
  }



  getAllDrinks(): Observable<Drink[]> {

    return this.http.get<Drink[]>(`${environment.apiUrl}/${this.drinkType}s`)
  }

  getDrinksPaginated(page: number = 0, limit: number = 10): Observable<Drink[]> {
    let params = new HttpParams()
      .set('page', String(page))
      .set('size', String(limit));

    return this.http.get<Drink[]>(`${environment.apiUrl}/${this.drinkType}s`, {params});
  }

  getAllDrinksCached() {
    return this.allDrinks$.pipe();
  }


  getOneCocktailById(id: number): Observable<Drink> {

    return this.http.get<Drink>(`${environment.apiUrl}/${this.drinkType}/${id}`);

  }

  getDrinksByIngredient(ingredient: string): Observable<Drink[]> {
    console.log(ingredient);

    return this.http.get<Drink[]>(`${environment.apiUrl}/${this.drinkType}s`).pipe(
      map(drinks => drinks.filter(drink =>
        Object.values(drink).slice(0, 12).includes(ingredient) ||
        Object.values(drink).slice(0, 12).includes(ingredient.replace(/\b\w{3,}\b/g, word =>
          word.replace(/^\w/, first => first.toLocaleUpperCase()))) ||
        Object.values(drink).slice(0, 12).includes(ingredient.toLowerCase()))
      )
    );
  }

  getFavouriteDrinks(drinkType: string): Observable<Drink[]> {
    return this.authService.getUsername().pipe(
      take(1),
      switchMap(username => {
        if (username) {
          const url = `${environment.apiUrl}/user/favourite${drinkType}s`;
          return this.http.get<Drink[]>(url).pipe(
            tap(favDrinks => {
              sessionStorage.setItem(`favourite${this.drinkType}s`, JSON.stringify(favDrinks));
            })
          );
        } else {
          return of([]);
        }
      })
    );
  }

  addFavourite(id: number, drinkTpe: string): Observable<String> {
    const url = `${environment.apiUrl}/user/favourite${this.drinkType}/${id}`;
    return this.http.put<String>(url, {}, {responseType: 'text' as 'json'});
  }

  removeFavourite(id: number, drinkTpe: string): Observable<String> {
    const url = `${environment.apiUrl}/user/rmfavourite${this.drinkType}/${id}`;
    return this.http.put<String>(url, {}, {responseType: 'text' as 'json'});
  }


  getFavouriteDrinksCached(): Observable<Drink[]> {
    return this.favouriteDrinks$;
  }

  getCocktailOfTheDayId(maxId: number): number {
    const today = new Date();
    const seed = today.getFullYear() * 10000 + (today.getMonth() + 1) * 100 + today.getDate();
    //TODO créer méthode backend pour récup tableau ID
    return this.pseudoRandomNumber(seed, 1, maxId);
  }

  updateAllListsFromExtAPI() {
    return [
      this.http.get<string>(`${environment.apiUrl}/cocktails/download`, {responseType: 'text' as 'json'}),
      this.http.get<string>(`${environment.apiUrl}/cocktails/downloadimages`, {responseType: 'text' as 'json'}),
      this.http.get<string>(`${environment.apiUrl}/cocktails/downloadpreviews`, {responseType: 'text' as 'json'}),
      this.http.get<string>(`${environment.apiUrl}/softdrinks/download`, {responseType: 'text' as 'json'}),
      this.http.get<string>(`${environment.apiUrl}/softDrinks/downloadimages`, {responseType: 'text' as 'json'}),
      this.http.get<string>(`${environment.apiUrl}/softdrinks/downloadpreviews`, {responseType: 'text' as 'json'}),
      this.http.get<string>(`${environment.apiUrl}/ingredients/download`, {responseType: 'text' as 'json'}),
      this.http.get<string>(`${environment.apiUrl}/ingredients/downloadimages`, {responseType: 'text' as 'json'}),
      this.http.get<string>(`${environment.apiUrl}/ingredients/downloadpreviews`, {responseType: 'text' as 'json'}),

    ]

  }

  private pseudoRandomNumber(seed: number, min: number, max: number): number {
    const x = Math.sin(seed) * 10000;
    return Math.floor((x - Math.floor(x)) * (max - min + 1)) + min;
  }

}


@Injectable({
  providedIn: 'root'

})
export class PersonalCocktailService {
  constructor(private http: HttpClient, private authService: AuthService) {
  }

  getAllPersonalDrinks(): Observable<PersonalCocktail[]> {
    return this.authService.getUsername().pipe(
      take(1),
      switchMap(username => {
        if (username) {
          const url = `${environment.apiUrl}/user/personalcocktails`;
          return this.http.get<PersonalCocktail[]>(url).pipe(
            map(drinks => drinks.map(drink => {
              drink.state = drink.state || State.SHOWED;
              return drink;
            })))
        } else
          return of([]);
      })
    );
  }


  getOnePersonalCocktailById(id: number): Observable<PersonalCocktail> {

    return this.http.get<PersonalCocktail>(`${environment.apiUrl}/user/personalcocktail/${id}`);

  }


  savePersonalCocktail(personalCocktail: PersonalCocktail): Observable<any> {


    return this.http.post(`${environment.apiUrl}/user/personalcocktail`, personalCocktail, {responseType: 'text' as 'json'});
  }

  deletePersonalCocktail(personalCocktail: PersonalCocktail): Observable<any> {
    return this.http.delete(`${environment.apiUrl}/user/personalcocktail/${personalCocktail.id}`, {responseType: 'text' as 'json'});
  }

  trashPersonalCocktail(personalCocktail: PersonalCocktail): Observable<string> {
    return this.http.put(`${environment.apiUrl}/user/personalcocktail/trash/${personalCocktail.id}`, {}, {responseType: 'text'});

  }

}
