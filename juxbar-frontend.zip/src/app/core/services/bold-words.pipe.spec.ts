import {BoldWordsPipe} from './bold-words.pipe';

describe('BoldWordsPipe', () => {
  it('create an instance', () => {
    const pipe = new BoldWordsPipe();
    expect(pipe).toBeTruthy();
  });
});
