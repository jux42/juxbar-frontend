import {Ingredient} from './ingredient';

describe('Cocktail', () => {
  it('should create an instance', () => {
    expect(new Ingredient()).toBeTruthy();
  });
});
