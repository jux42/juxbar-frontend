import {SoftDrink} from './softDrink';

describe('SoftDrink', () => {
  it('should create an instance', () => {
    expect(new SoftDrink()).toBeTruthy();
  });
});
