export enum State {
  SHOWED = 'SHOWED',
  HIDDEN = 'HIDDEN',
  TRASHED = 'TRASHED'
}
