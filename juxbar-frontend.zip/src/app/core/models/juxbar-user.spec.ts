import { JuxbarUser } from './juxbar-user';

describe('JuxbarUser', () => {
  it('should create an instance', () => {
    expect(new JuxbarUser()).toBeTruthy();
  });
});
