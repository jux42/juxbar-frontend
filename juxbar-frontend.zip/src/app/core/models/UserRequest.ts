export class UserRequest {
  constructor(public username: string) {

  }
}
