import {PersonalCocktail} from './personal-cocktail';

describe('PersonalCocktail', () => {
  it('should create an instance', () => {
    expect(new PersonalCocktail()).toBeTruthy();
  });
});
