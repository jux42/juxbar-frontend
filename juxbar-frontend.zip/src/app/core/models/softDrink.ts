import {Drink} from "./drink";

export class SoftDrink extends Drink {

  override id !: number;

  override idDrink!: string;

  _uniqueKey?: number;


}
